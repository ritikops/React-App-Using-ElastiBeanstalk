This file has moved [here](https://github.com/facebook/create-react-app/blob/main/packages/cra-template/template/README.md)
